import { useState } from 'react'
import Contador from './componentes/Contador'
import Ranking from './componentes/Ranking/Ranking'

function App() {

  return (
    <>
      <Ranking/>
      {/* <Contador/> */}
    </>
  )
}

export default App
